package com.techhhnews;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TechhhnewsJavaApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(TechhhnewsJavaApiApplication.class, args);
	}

}
